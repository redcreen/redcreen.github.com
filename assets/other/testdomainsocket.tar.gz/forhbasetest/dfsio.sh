#!/bin/bash
files=${1:-2}
filesize=${2:-10240}

base_home="/home/hadoop/zhongjian/forhbasetest"
hadoop_home="/home/hadoop/hadoop-current"
jthost="r65f20008.cm10"

$hadoop_home/bin/hadoop-daemon.sh start datanode

$hadoop_home/bin/hadoop fs -rmr /benchmarks

ssh $jthost "$hadoop_home/bin/hadoop jar $hadoop_home/hadoop-0.19.1-dc-mapred-test.jar TestDFSIO -write -nrFiles $files -fileSize $filesize"


cmd="$hadoop_home/bin/hadoop jar $hadoop_home/hadoop-0.19.1-dc-mapred-test.jar TestDFSIO -read -nrFiles $files -fileSize $filesize"

out=$base_home/out_${files}_${filesize}
mkdir -p $out

function replace_jar_conf() {
  cp $base_home/$1/*.jar $hadoop_home
  cp $base_home/$2 $hadoop_home/conf/hadoop-site.xml
}
function restart_dn_tt() {
  while test `jps |grep 'DataNode'|awk '{print $1}'` 
  do
    $h $hadoop_home/bin/hadoop-daemon.sh stop datanode
    sleep 1
  done
  $hadoop_home/bin/hadoop-daemon.sh start datanode
  while test `jps |grep 'TaskTracker'|awk '{print $1}'` 
  do
    $h $hadoop_home/bin/hadoop-daemon.sh stop tasktracker
    sleep 1
  done
  $hadoop_home/bin/hadoop-daemon.sh start tasktracker
  sleep 1;
  if ! test `jps |grep 'DataNode'|awk '{print $1}'` ; then
    echo "datanode error : $*" >> $out/error
  fi
  if ! test `jps |grep 'TaskTracker'|awk '{print $1}'` ; then
    echo "datanode error : $*" >> $out/error
  fi
  while test "`$hadoop_home/bin/hadoop dfsadmin -safemode get 2>&1 |grep "Safe mode is ON"`"
  do 
    echo "wait for safemode leave"
    sleep 1
  done
  for i in {1..15}; do 
    sleep 1 ; #wait for datanode report
  done
}
function drop_cache() {
  echo 3 |sudo tee  /proc/sys/vm/drop_caches
}
function submitjob() {
  ssh $jthost "$cmd" 1>> $out/$1 2>&1
}
mv $out ${out}_`date +%s`
mkdir $out -p
#domain socket + local + nochecksum + clean system cache
replace_jar_conf domainsocket hadoop-site.xml.truetrue
restart_dn_tt 
drop_cache
submitjob "ds.local.skipchecksum.cleancache.1"
drop_cache
submitjob "ds.local.skipchecksum.cleancache.2"
#domain socket + local + no checksum + no clean system cache
submitjob "ds.local.skipchecksum.nocleancache.1"
submitjob "ds.local.skipchecksum.nocleancache.2"
#domain socket + local + checksum + clean system cache
replace_jar_conf domainsocket hadoop-site.xml.truefalse
restart_dn_tt 
drop_cache
submitjob "ds.local.checksum.cleancache.1"
drop_cache
submitjob "ds.local.checksum.cleancache.2"
#domain socket + local + checksum + no clean system cache
submitjob "ds.local.checksum.nocleancache.1"
submitjob "ds.local.checksum.nocleancache.2"
#domain socket + rpc + checksum +  clean system cache
replace_jar_conf domainsocket hadoop-site.xml.false
restart_dn_tt 
drop_cache
submitjob "ds.rpc.checksum.cleancache.1"
drop_cache
submitjob "ds.rpc.checksum.cleancache.2"
#domain socket + rpc + checksum +  no clean system cache
submitjob "ds.rpc.checksum.nocleancache.1"
submitjob "ds.rpc.checksum.nocleancache.2"
#domain socket + rpc + nochecksum +  clean system cache
replace_jar_conf domainsocket_nochecksum hadoop-site.xml.false
restart_dn_tt 
drop_cache
submitjob "ds.rpc.skipchecksum.cleancache.1"
drop_cache
submitjob "ds.rpc.skipchecksum.cleancache.2"
#domain socket + rpc + nochecksum +  no clean system cache
submitjob "ds.rpc.skipchecksum.nocleancache.1"
submitjob "ds.rpc.skipchecksum.nocleancache.2"
