#!/bin/bash
base_dir=`dirname $0`

$base_dir/dfsio.sh 2 4 
$base_dir/dfsio.sh 2 16
$base_dir/dfsio.sh 2 128
$base_dir/dfsio.sh 2 1024
$base_dir/dfsio.sh 2 10240


$base_dir/dfsio.sh 4 4 
$base_dir/dfsio.sh 4 16
$base_dir/dfsio.sh 4 128
$base_dir/dfsio.sh 4 1024
$base_dir/dfsio.sh 4 10240


$base_dir/dfsio.sh 8 4 
$base_dir/dfsio.sh 8 16
$base_dir/dfsio.sh 8 128
$base_dir/dfsio.sh 8 1024
$base_dir/dfsio.sh 8 10240
